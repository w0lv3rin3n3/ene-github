#include "LED.h"

LED::LED(const int pin) : Switchable(pin){
	
}